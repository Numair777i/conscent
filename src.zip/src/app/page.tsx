import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HeroSlider } from "@/components/HeroSlider";
import { ProductCard } from "@/components/ProductCard";
import { TrialSetButton } from "@/components/TrialSetButton";
import { products } from "@/data/products";
import { formatINR } from "@/lib/utils";
import tester1 from "@/assets/Pack-of-3.webp";

export const metadata: Metadata = {
  title: { absolute: "CONSCENT | Discover Indie Luxury Fragrances" },
  description:
    "Discover indie luxury fragrances in concentrated extrait de parfum. 25–30% oil, striking projection and 10–12+ hour longevity, handcrafted in India.",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_IN",
    siteName: "CONSCENT",
    url: "/",
    title: "CONSCENT | Discover Indie Luxury Fragrances",
    description:
      "Discover indie luxury fragrances in concentrated extrait de parfum. 25–30% oil, striking projection and 8–10+ hour longevity, handcrafted in India.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "CONSCENT — indie luxury extrait de parfum",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "CONSCENT | Discover Indie Luxury Fragrances",
    description:
      "Discover indie luxury fragrances in concentrated extrait de parfum. 25–30% oil, striking projection and 10–12+ hour longevity, handcrafted in India.",
    images: ["/og-image.jpg"],
  },
};

const faqs = [
  {
    q: "How long does a CONSCENT scent last?",
    a: "Our extraits run 20–30% concentration and typically last 8–10 hours on skin, longer on fabric.",
  },
  {
    q: "Can I try before buying a full bottle?",
    a: "Yes. The Trial Set gives you all three house scents in 8ML vials, and the full ₹399 is credited against your first full-size purchase.",
  },
  {
    q: "What are the shipping timelines?",
    a: "Metro cities: 2–3 working days. Rest of India: 4–6 working days. Free express shipping on orders above ₹399.",
  },
  {
    q: "Do you accept returns?",
    a: "Unopened full-size bottles can be returned within 7 days of delivery. Trial sets are final sale due to hygiene standards.",
  },
];

export default function Home() {
  const trial =
    products.find((p) => p.slug === "trial-set") ??
    products[products.length - 1];

  const trialSlug = trial?.slug ?? "trial-set";
  const trialUrl = `/parfums/${trialSlug}`;

  // Limit display to 4 products for now
  const displayedProducts = products.slice(0, 4);

  return (
    <div className="flex flex-col">
      <HeroSlider />

      {/* Value Badges Banner (Hidden on mobile to eliminate duplication; visible on desktop) */}
      <section className="hidden md:block bg-ink text-background py-4 border-b border-white/5">
        <div className="mx-auto grid w-full max-w-[1400px] grid-cols-2 gap-4 px-4 text-center text-[10px] font-semibold tracking-[0.2em] uppercase sm:px-6 md:grid-cols-4 select-none">
          <span>Free express shipping over ₹399</span>
          <span>Cash on delivery available</span>
          <span>8–10 hr extrait projection</span>
          <span>Cruelty-free &amp; handcrafted</span>
        </div>
      </section>

      {/* Trial Set Feature Section */}
      <section className="mx-auto w-full max-w-[1400px] px-4 py-20 sm:px-6">
        <div className="border-border grid border md:grid-cols-2 overflow-hidden bg-card">
          {/* Clickable Image Container */}
          <Link
            href={trialUrl}
            className="group bg-muted relative min-h-[340px] md:min-h-full block overflow-hidden"
            aria-label="View Trial Set details"
          >
            <Image
              src={tester1}
              alt="CONSCENT Trial Set of three vials"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          </Link>

          <div className="flex flex-col justify-center p-8 sm:p-12 lg:p-16">
            <span className="bg-brand text-brand-foreground w-fit px-2.5 py-1 text-[10px] font-bold tracking-[0.25em] uppercase">
              Start Here
            </span>

            {/* Clickable Title */}
            <Link href={trialUrl} className="group mt-5 block w-fit">
              <h2 className="font-heading text-5xl sm:text-6xl tracking-tight transition-colors group-hover:text-brand">
                Trial set
                <br />
              </h2>
            </Link>

            {/* Clickable Description */}
            <Link
              href={trialUrl}
              className="text-muted-foreground hover:text-foreground mt-4 max-w-md text-sm leading-relaxed sm:text-base block transition-colors"
            >
              Three 8ML extrait vials. Live with each profile on skin for a
              week, then put the full ₹399 purchase price towards the 50ML or
              100ML bottle you love. Zero blind-buy regret.
            </Link>

            {/* Pricing Summary */}
            <div className="mt-6 flex items-baseline gap-3">
              <span className="text-3xl font-bold">{formatINR(399)}</span>
              <span className="text-muted-foreground text-sm line-through">
                {formatINR(599)}
              </span>
              <span className="bg-primary text-primary-foreground px-2 py-0.5 text-[10px] font-bold tracking-widest uppercase">
                Save 33%
              </span>
            </div>

            {/* Action Buttons Row */}
            <div className="mt-8 flex flex-wrap gap-3">
              {trial && <TrialSetButton product={trial} />}
              <Link
                href={trialUrl}
                className="border-foreground/30 hover:bg-foreground hover:text-background border px-8 py-4 text-xs font-bold tracking-[0.25em] uppercase transition-colors"
              >
                Details
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* House Catalog Grid (Capped to 4 products) */}
      <section className="mx-auto w-full max-w-[1400px] px-4 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-4">
          <h2 className="font-heading text-5xl sm:text-7xl tracking-tight">
            The <span className="text-brand">House</span>
          </h2>
          <Link
            href="/parfums"
            className="text-xs font-bold tracking-[0.25em] uppercase hover:text-brand transition-colors underline underline-offset-8"
          >
            View all ({products.length})
          </Link>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {displayedProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="mx-auto w-full max-w-[900px] px-4 pt-24 pb-8 sm:px-6">
        <h2 className="font-heading text-5xl sm:text-6xl tracking-tight">
          FA<span className="text-brand">Qs</span>
        </h2>
        <Accordion type="single" collapsible className="mt-8">
          {faqs.map((f) => (
            <AccordionItem
              key={f.q}
              value={f.q}
              className="border-border border-b"
            >
              <AccordionTrigger className="text-left text-sm font-bold tracking-[0.1em] uppercase hover:text-brand py-5">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </div>
  );
}
